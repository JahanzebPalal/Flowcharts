package com.Jahanzeb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class History
 */
@WebServlet("/History")
public class History extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private String uname = null;
    public History() {
        super();
        // TODO Auto-generated constructor stub
  
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// Get request parameters for username and password
		
		//String pwd = request.getParameter("pwd");
		//String uname = request.getAttribute("user").toString();
    	//Copy pasted from login
    	uname = request.getSession().getAttribute("CURRENT_USER").toString();//authenticator.getUsername()
		String Output ="";
		System.out.println("HISUsername= "+ uname);

		ArrayList <String> Conversions = new ArrayList<String>();
		
		DBUtility DBConnector = new DBUtility(uname.toString(),"");
		try {
			// DO NOT REMOVE CONNECT TO DB OR THIS LINE. IT GETS LE CONNECTION
			//Connects to the database
			DBConnector.ConnectToDB();
			//Uses the GetHistory method in DBUtility
			Conversions = DBConnector.GetHistory();
			//Unifying(?) the ArrayList into 1 string to send to the jsp
			for(int i = 0; i<Conversions.size(); i++){
			Output = Output + "<h4>"+ Conversions.get(i)+"</h4>";
			}
			System.out.println("Conversions the user has done");
			System.out.println(Conversions);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("History no work");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("History no work123");
		}
		System.out.println("Output:");
		System.out.println(Output);
		System.out.println("Conversion sent to webpage");
		//Sending the conversion history to the jsp
		request.getSession().setAttribute("History",Output);//authenticator.getUsername()
		//forwarding the user back to the jsp
		request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);
	}
}
