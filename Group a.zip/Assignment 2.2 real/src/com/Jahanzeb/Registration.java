package com.Jahanzeb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends Login {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Get request parameters for username and password
		String Reguname = request.getParameter("Reguname");
		String Regpwd = request.getParameter("Regpwd");
		String Message =" Cry about it. Cope and seethe";

		if (Reguname == "" || Regpwd == "" ){
			request.setAttribute("message", "Please fill all in your credentials");
			//Sends the user back to login page
			request.getRequestDispatcher("/Index.jsp").forward(request, response);}

		else {
			//Creates and object call methods in the DBUtility class
			DBUtility DBConnector = new DBUtility(Reguname,Regpwd);
			try {
				//establish a connection with the database
				DBConnector.ConnectToDB();
				//If account successfully make it stores the message to send to the user. 
				//RegisterUser writes the data to the database and returns a message
				Message = DBConnector.RegisterUser();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Couldn't register due to SQL error or account already made.");
				//send error message to the user
				request.setAttribute("message", "Couldn't register due to SQL error.");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("REGUsername= "+ Reguname +" REGpwd= "+ Regpwd);
			//Send the message to the user
			request.setAttribute("message", Message);
			//Sends the user back to login page
			request.getRequestDispatcher("/Index.jsp").forward(request, response);}
	} 
}
