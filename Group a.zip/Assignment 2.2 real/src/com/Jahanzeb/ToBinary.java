package com.Jahanzeb;
import java.util.ArrayList;

//Errors in Pseudocode, please fix!!
public class ToBinary {
	private String HexaValue;


	public ToBinary (String Hexa)//Constructor.
	{
		HexaValue = Hexa;

	}


	public String Converter()
	{
		String HexaToConvert =HexaValue;
		String ConvertedValue="";
		String InvertedValue="";

		ArrayList<Character> HexaChars = new ArrayList<Character>();
		int Binary = 0;
		int HexaIndex = 0;
		int HexaIndex2 = 0;
		char [] InvertArray = new char [4];
		int InvertIndex =0;
		//Serialise Array
		for (int i=0 ;i!= HexaToConvert.length(); i++)
		{
			HexaChars.add(i, HexaToConvert.charAt(i) );
			//For testing. System.out.println(HexaChars.get(i) +" has been added. ASCII=" + (int) HexaChars.get(i));
		}

		for (int i=0 ;i!= HexaChars.size(); i++)
		{
			//For testing. System.out.println("works?");
			//Get the ASCII value and subtract 50 so we get the hexadecimal digit value since 
			//A(10 in hexa) is the first 'Alphabet digit'(Digits that aren't composed of numbers) 
			//of the hexadecimal number system. 

			//Initialisaton for the while loop
			//For letters
			if((int) HexaChars.get(i) >64 && (int) HexaChars.get(i) <71)
			{Binary = ((int) HexaChars.get(i)-55);}
			//For numbers
			else if((int) HexaChars.get(i) >48 && (int) HexaChars.get(i) <58)
			{Binary = ((int) HexaChars.get(i)-48);}


			//Conversion Loop
			while(HexaIndex<4){
				//This is to account for the fact that % would only accounts for numbers >2
				// meaning that 1 and 2 would be coverted incorrectly.
				//The reason it works for 2 is because of line 59 which gives
				if(Binary == 1){ConvertedValue=ConvertedValue+"1";} //For testing. System.out.println("llllll" +" " + Binary);}

				else if(Binary%2==0 ){ConvertedValue=ConvertedValue+"0"; }
				else if (Binary%2 ==1) {ConvertedValue=ConvertedValue+"1";}	

				Binary = Binary/2;
				++HexaIndex;
				//For testing. System.out.println("works2?" + " " + Binary + " "+ i + " Index = " + HexaIndex);		
			} 

			//Determining from which index(of the string 'ConvertedValue') to start inverting from.
			InvertIndex = 5*(i);
			
			//Storing the characters in an array to later invert the string
			//I did this because I don't know how to declare a queue or a stack in Java :/
			for(int j=0; j<=3; j++){InvertArray[j] = ConvertedValue.charAt(InvertIndex+j);
			//For testing. System.out.println(InvertArray[j] +" has been added");
			}

			//The actual inverting of the string by reading the Array backwards.
			for(int j=3; j>=0; j--){InvertedValue = InvertedValue + InvertArray[j];}
			InvertedValue = InvertedValue + " ";
			//For testing. System.out.println("The inverted value is "+ InvertedValue + " and the i is " + i);

			//Setting HexaIndex back to 0 for the next iteration of the FOR Loop so the while loop
			//runs better. Also given a space in between the Binary value of the hexadecimal digits
			// so it is easier to understand.	
			HexaIndex=0;
			ConvertedValue = ConvertedValue + " ";
		}

		//For testing. System.out.println("works3?");
		ConvertedValue = InvertedValue;
		return ConvertedValue;
	}

}
