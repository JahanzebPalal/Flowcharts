package com.Jahanzeb;
import java.util.ArrayList;

public class ToDecimal {
	private String HexaValue;

	public ToDecimal (String Hexa)//Constructor.
	{
		HexaValue = Hexa;
	}

	public String Converter()
	{
		String HexaToConvert =HexaValue;
		int ConvertedValue=0;
		ArrayList<Character> HexaChars = new ArrayList<Character>();
		int Decimal = 0;
		int Indice =1;

		HexaToConvert=HexaValue;

		//Serialise Array
		for (int i=0 ;i!= HexaToConvert.length(); i++)
		{
			HexaChars.add(i, HexaToConvert.charAt(i) );
			//For testing. System.out.println(HexaChars.get(i) +" has been added. ASCII=" + (int) HexaChars.get(i));
		}

		//For testing. System.out.println("Works?");
		
		for (int i= HexaChars.size()-1 ; i>=0 ; i--)
		{
			if((int) HexaChars.get(i) >64 && (int) HexaChars.get(i) <71)
			{Decimal = ((int) HexaChars.get(i)-55);}
			//For numbers
			else if((int) HexaChars.get(i) >48 && (int) HexaChars.get(i) <58)
			{Decimal = ((int) HexaChars.get(i)-48);}
			
			//For setting which indice of 16 to multiple the decimal by.
			for(int j =0; j!=(HexaChars.size()-1)-i;j++){Indice= Indice*16;}
			
			ConvertedValue=ConvertedValue+(Decimal*(Indice));
			
			
			//For testing. System.out.println(" Converted Value = "+ConvertedValue+ " Decimal = " + Decimal+ " i = "+ i + " Indice = "+ Indice);
			Indice = 1;
		}

		String output = String.valueOf(ConvertedValue);
		System.out.println("Pls work = "+ output);
		return output;
	}
}

