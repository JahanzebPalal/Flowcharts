package com.Jahanzeb;

public class GhazDecToHex {

	
	private String toConvert = "";
	GhazDecToHex(String toConvert){
		this.toConvert = toConvert;
	}
	public String Convertor(String toConvert)
	{
		String DecToHex = "";		// this is an empty string into which the values will be stored for octals
		char hex [] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};	
		// this array contains all the values of the hexadecimal system and we have used char as it can store both digits and alphabets 
		int temp = Integer.valueOf(toConvert);
		int remainder;
		if(Integer.valueOf(toConvert) == 0)
		{
			System.out.println(0);
		}

		else if (Integer.valueOf(toConvert) >= 0 && Integer.valueOf(toConvert) <= 999)	// the condition is so that all values are no greater than three digits
		{
			while(temp != 0 ) 			// the condition is so that the loop will run until quotient becomes 0
			{
				{
					remainder = temp % 16;		// the remainder will be stored in 'remainder' variable
					DecToHex = hex [remainder] + DecToHex; 
					/* the value of the remainder will be used in the array to call the value at that position and store it
					   in the DecToHex string. When the loop is repeated, new values will be added to the left of the previous string 	*/	
					temp /= 16;					// divide temp by 16 in case of hexadecimal to get value of new quotient for the loop
				}
			}
			System.out.println("The Decimal Number in Octal is: " + DecToHex); 
		}
		else{System.out.println("Enter a Valid Value");}
		
		return DecToHex;
	}
}
