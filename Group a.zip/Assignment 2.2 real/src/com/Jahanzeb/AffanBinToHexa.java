/**
 * 
 */
package com.Jahanzeb;

/**
 * @author KalaBaz
 *
 */
public class AffanBinToHexa {
	
	private String hexa = "";

	public AffanBinToHexa(String toConvert) {
		// TODO Auto-generated constructor stub
		hexa=toConvert;
	}

	public String convertBinaryToHexadecimal(String number) {
		String hexa1 = "";
		String [] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a",
				"b", "c", "d", "e", "f" };
		if ((number != null && !number.isEmpty()))         
		{
			AffanBinToDec affanObj = new AffanBinToDec(); //int decimal = convertBinaryToDecimal(number);
			
			int decimal = affanObj.convertBinaryToDecimal(number);
			while (decimal > 0)
			{
				hexa = hex[decimal % 16]+ hexa1 ;//
				decimal /= 16;
			}
			System.out.println("The hexa decimal number is: " + hexa);    
		}
		else{
			hexa = "sorry";
			System.out.println(hexa);

		}

		return hexa;


	}
}
