package com.Jahanzeb;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Converter
 */
@WebServlet("/Converter")
public class Converter extends Login {
	private static final long serialVersionUID = 1L;
	public String Answer = null;
	String Uname = null;
	static String ToConvert;

	private static boolean validationcheck(String Hexavalue, String convertFrom){
		boolean valid = false;
		try{
		if(convertFrom.equals("Hexa")){
			int count = 0;
			char[] digits = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
			for(int i =0; i!=Hexavalue.length(); i++){
				for(int i2 =0; i2!=digits.length; i2++){if(Hexavalue.charAt(i)==digits[i2]){count++;}}
			}
			if(count ==Hexavalue.length() ){valid = true;}
			if(Hexavalue.length()>2 ){valid = false;}
			if(Hexavalue.equals("")){valid = false;}
			return valid;}
		if(convertFrom.equals("Binary"))
		{
			 boolean isBinary = false;
			 String number=ToConvert;
		        if (number != null && !number.isEmpty()) {
		            long num = Long.parseLong(number);
		            while (num > 0) {
		                if (num % 10 <= 1) {
		                    isBinary = true;
		                } else {
		                    isBinary = false;
		                    break;
		                }
		                num /= 10;
		            }
		        }
		       
		        return isBinary;
		}
		if(convertFrom.equals("Octal"))
		{
			
		}
		if(convertFrom.equals("Denary"))
		{
			
		}
		
		
		}catch(NullPointerException e){System.out.println("User didn't select a numbering system");}
		return true;
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		//Parameters taken from the jsp. ConvertTo is the number system the code is tasked to convert to and ToConvert is the value to convert
		String ConvertTo= request.getParameter("ConvertTo");
		ToConvert= request.getParameter("bin-number");
		String ConvertFrom= request.getParameter("ConvertFrom");
		//Copy pasted from login
		//Retrieve the username to pass to the object of the DBUtility class
		Uname = request.getSession().getAttribute("CURRENT_USER").toString();//authenticator.getUsername()
		System.out.println("Conversion Uname =" +Uname);
		//Do something with the user input .....
		System.out.println("Received = " + ConvertTo + " and " + ToConvert + " and " + ConvertFrom);


		//To check if  the data send by the user is valid.if valid do the conversion and if not give an error message
		if(validationcheck(ToConvert, ConvertFrom) && ToConvert!="" && ConvertTo !=null){
			//Processing
			//Call the respective converter and create and object of that converter's class to convert the value
			
			//Jahanzeb's convertor
			if(ConvertFrom.equalsIgnoreCase("Hexa"))
			{
			if (ConvertTo.equalsIgnoreCase("Binary")){ToBinary output = new ToBinary(ToConvert); Answer = output.Converter();}
			else if (ConvertTo.equalsIgnoreCase("Denary")){ToDecimal output = new ToDecimal(ToConvert);Answer = output.Converter();}
			}
			//Affan's convertor
			if(ConvertFrom.equalsIgnoreCase("Binary"))
			{
				if (ConvertTo.equalsIgnoreCase("Hexa")){AffanBinToHexa output = new AffanBinToHexa(ToConvert); Answer = output.convertBinaryToHexadecimal(ToConvert);}
				else if (ConvertTo.equalsIgnoreCase("Denary")){AffanBinToDec output = new AffanBinToDec();Answer = String.valueOf(output.convertBinaryToDecimal(ToConvert));}
			}
			//Ghazanfar's convertor
			if(ConvertFrom.equalsIgnoreCase("Denary"))
			{
				if (ConvertTo.equalsIgnoreCase("Hexa")){GhazDecToHex output = new GhazDecToHex(ToConvert); Answer = output.Convertor(ToConvert);}
				else if (ConvertTo.equalsIgnoreCase("Octal")){GhazDecToOct output = new GhazDecToOct(ToConvert);Answer = output.Convertor(ToConvert);}
			}
			//Hussnain's converter
			
			
			//Daksh's converter
			
			
			//
			
			
			
			//Passing an empty string along with the username to DB utility since the converter class doesn't access any method that requires the password
			DBUtility db = new DBUtility(Uname,"");

			try {
				//establish connection with the database
				db.ConnectToDB();
				//Call the write to history method from DBUtility to store the conversion in the JHistory table in the MySQL database
				db.WriteToHistory(ToConvert+ "=" +Answer);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Couldn't write to history");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 ToConvert = null;
			System.out.println(Answer);
			//Respond to the users input/request after processing
			request.getSession().setAttribute("CONVERTER_RESULT", Answer );
			request.getSession().setAttribute("Input", "" );
			//Forward the user back to user welcome
			request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);
		}
		//If invalid input then displace appropriate error message and forward back to user-welcome.jsp
		else{
			if(ToConvert=="" && ConvertTo !=null ){request.getSession().setAttribute("Input", "Please enter a value");
			request.getSession().setAttribute("CONVERTER_RESULT", "Could not retrieve your answer");
			request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);}

			else if(ConvertTo ==null && ToConvert!="" ){request.getSession().setAttribute("Input", "Please select a number system to convert to");
			request.getSession().setAttribute("CONVERTER_RESULT", "Could not retrieve your answer");
			request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);}

			else if (ToConvert=="" && ConvertTo ==null){request.getSession().setAttribute("Input", "Please enter a value and select a number system to convert to");
			request.getSession().setAttribute("CONVERTER_RESULT", "Could not retrieve your answer");
			request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);}

			else{
				request.getSession().setAttribute("Input", "Illegal Input. All Alphabets must be capital and letters after F cannot be inserted. Only 2 digit values can be entered." );
				request.getSession().setAttribute("CONVERTER_RESULT", "Could not retrieve your answer");
				request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);}
		}
	}

}
