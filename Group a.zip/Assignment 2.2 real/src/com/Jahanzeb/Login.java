package com.Jahanzeb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;


import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Zear
 * A simple HTTP web application to accept username and password using the POST method.
 * This class serves as a template for L1 students.
 */

@WebServlet("/Login")

public class Login extends HttpServlet{
	private Authenticator authenticator = null;
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get request parameters for username and password
		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		System.out.println("Username= "+ uname +" password= "+ pwd);
		authenticator = new Authenticator(uname, pwd);
		//Checkng if the user entered any credentials or not
		if (uname == "" || pwd == "" ){
			request.setAttribute("error", "Please fill all in your credentials");
			//Sends the user back to login page
			request.getRequestDispatcher("/Index.jsp").forward(request, response);}

		else {

			try {
				if (authenticator.authenticateUser()) {
					// Add variable to session cookie
					request.getSession().setAttribute("CURRENT_USER",uname);//authenticator.getUsername()
					// Session cookie becomes invalid after 10s
					request.getSession().setMaxInactiveInterval(120);
					// Forward to welcome page
					request.getRequestDispatcher("/WEB-INF/user-welcome.jsp").forward(request, response);
				} else {
					request.setAttribute("error", authenticator.getAuthenticationMessage());
					request.getRequestDispatcher("/Index.jsp").forward(request, response);
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("No work 1");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("No work");
			}
		}
	}
} 
