package com.Jahanzeb;

public class GhazDecToOct {
	
	
	private String toConvert = "";
	GhazDecToOct(String toConvert)
	{	
		this.toConvert = toConvert;
	}
	public String Convertor(String toConvert)
	{
		String DecToOct = "";			// this is an empty string into which the values will be stored for octals
		char oct [] =  {'0', '1', '2', '3', '4', '5', '6', '7'};  // this array contains all the values of the octal system
		int temp = Integer.valueOf(toConvert);
		int remainder;
		if(Integer.valueOf(toConvert) == 0)
		{
			System.out.println(0);
		}

		else if (Integer.valueOf(toConvert) >= 0 && Integer.valueOf(toConvert) <= 999)	// the condition is so that all values are no greater than three digits
		{
			while(temp != 0 ) 			// the condition is so that the loop will run until quotient becomes 0
			{
				{
					remainder = temp % 8;	// the remainder will be stored in 'remainder' variable

					DecToOct = oct[remainder] + DecToOct;
					/* (line 32) the value of the remainder will be used in the array to call the value at that position and store it
					   in the DecToOct string. When the loop is repeated, new values will be added to the left of the previous string 	*/	
					temp /= 8;				// divide temp by 8 in case of octal to get value of new quotient for the loop 
				}		
			}
			System.out.println("The Decimal Number in Octal is: " + DecToOct); 
		}
		else{System.out.println("Enter a Valid Value");}

		return DecToOct;
	}

}
