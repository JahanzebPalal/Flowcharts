package com.Jahanzeb;

public class AffanBinToDec {

	
	
	 public AffanBinToDec() {
		// TODO Auto-generated constructor stub
		 //decimal=Integer.valueOf(toConvert);
	}

	public static int convertBinaryToDecimal(String number) {
	        int length = number.length() - 1;
	       int decimal = 0;
	       // if (isBinary(number)) {
	            char[] digits = number.toCharArray();
	            for (char digit : digits) {
	                if (String.valueOf(digit).equals("1")) {
	                    decimal += Math.pow(2, length);
	                }
	                --length;
	            }
	            System.out.println("The decimal number is : " + decimal);
	        //}
	        return decimal;
	    }

	
	
	
	
	
	
}
