package com.Jahanzeb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.PreparedStatement;

public class DBUtility {

	private  static Connection Con = null;
	private  ResultSet RS = null;
	private String SearchUname =null;
	private String SearchPassword =null;

	//Constructor
	DBUtility (String Uname, String password){
		SearchUname = Uname;
		SearchPassword = password;
	}
	//Method to get the userID with a certain username in the database 
	private String GetUserID(String Username) throws SQLException{
		String ID = "";
		Statement stmt = Con.createStatement();
		//Choice variable to see if the ID is to be search for in the history or the user table
		//RS =stmt.executeQuery("SELECT * FROM Jahanzeb");
		RS =stmt.executeQuery("SELECT * FROM USERS");
		//loop to cycle through the Database
		while (RS.next()) {
			//String Uname = RS.getString("Name");
			String Uname = RS.getString("username");
			ID = RS.getString("ID");
			//System.err.println("------\n" + username + "," + token + "," + ID + "\n------\n");
			System.out.println("1234Name = " + Uname);
			System.out.println("1234UserName = " + Username);
			//Check if found then return true
			if(Uname.equals(Username)){
				stmt.close();
				//RS.close();
				System.out.println("6666666666");
				return ID;}
		}
		//Not found then return true since the result variable is already initialised to false.
		//Con.close();
		return "No such user";}


	//Method to see if user is Present in the database
	private Boolean UserPresent(String Username) throws SQLException{
		Boolean Return = false;
		Statement stmt = Con.createStatement();
		//RS =stmt.executeQuery("SELECT username FROM Jahanzeb");
		RS =stmt.executeQuery("SELECT username FROM USERS");
		//loop to cycle through the Database
		while (RS.next()) {
			//String Uname = RS.getString("Name");
			String Uname = RS.getString("username");
			//System.err.println("------\n" + username + "," + token + "," + ID + "\n------\n");
			System.out.println("Name = " + Uname);
			//Check if found then return true
			if(Uname.equals(Username)){
				//stmt.close();
				//RS.close();
				//System.out.println("6666666666");
				Con.close();
				Return = true;}
		}
		//Not found then return true since the result variable is already initialised to false.
		//Con.close();
		return Return;}

	//Method to see if an ID in present in the database
	private Boolean IDPresent(String ID, int choice) throws SQLException{
		try {
			ConnectToDB();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("I hate SQLite");
		}
		Boolean Return = false;
		Statement stmt = Con.createStatement();
		//Choice variable to see if the ID is to be search for in the history or the user table
		//For Jahanzeb
		//if(choice ==1){RS =stmt.executeQuery("SELECT * FROM Jahanzeb");
		if(choice ==1){RS =stmt.executeQuery("SELECT * FROM USERS");
		while (RS.next()) {
			String ID2 = RS.getString("ID");
			//System.err.println("------\n" + username + "," + token + "," + ID + "\n------\n");
			System.out.println("ID = " + ID);
			//Check if found then return true
			if(ID2.equals(ID)){
				stmt.close();
				RS.close();
				//Con.close();
				Return = true;}
		}
		}
		//For JHistory
		//if(choice ==2){RS =stmt.executeQuery("SELECT * FROM JHistory");
		if(choice ==2){RS =stmt.executeQuery("SELECT * FROM HISTORY");
		while (RS.next()) {
			String ID2 = RS.getString("conversionID");
			//System.err.println("------\n" + username + "," + token + "," + ID + "\n------\n");
			System.out.println("ID = " + ID);
			//Check if found then return true
			if(ID2.equals(ID)){
				stmt.close();
				RS.close();
				//Con.close();
				Return = true;}
		}
		}
		//loop to cycle through the Database
		//Not found then return false since the result variable is already initialised to false.
		Con.close();
		return Return;}

	//Method to collect conversions done by any 1 account
	public ArrayList<String> GetHistory() throws SQLException{
		try {
			ConnectToDB();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed to connect.");
		}
		Statement stmt = Con.createStatement();
		String HisID=GetUserID(SearchUname); 
		System.out.println("HisID = " + HisID);
		//RS = stmt.executeQuery("SELECT * FROM JHistory"+" WHERE UserID ="+ "'"+HisID+"'");
		RS = stmt.executeQuery("SELECT * FROM HISTORY"+" WHERE UserID ="+ "'"+HisID+"'");
		//String conversionID = null;
		int Index = 0;
		ArrayList <String> Conversions = new ArrayList<String>();       
		//Cycle through the database
		while (RS.next()) {
			String ConID = RS.getString("conversionID");
			String UID = RS.getString("UserID");
			//System.err.println("------\n" + username + "," + token + "," + ID + "\n------\n");
			if(UID.equals(HisID)){
				Conversions.add(RS.getString("conversion"));
				System.out.println("Added to Conversion ArrayList");
				//stmt.close();
				//RS.close();
				//return Conversions;
			}
		}
		RS.close();
		stmt.close();
		Con.close();
		//Returns null if ID not found
		return Conversions;
	}

	//Method to write a conversion done by a user to the database
	public void WriteToHistory(String Conversion) throws SQLException{

		String ID = GetUserID(SearchUname);
		//Create a random ID for the primary key
		String conversionID=java.util.UUID.randomUUID().toString();
		//To make sure the ID isn't already stored in the database, if it isn't then continue storing the data
		while(IDPresent(conversionID,2)!=false){conversionID=java.util.UUID.randomUUID().toString();}
		PreparedStatement ps = null;
		//Writing the data to the database
		if(IDPresent(conversionID,2) != true){
			//ps = Con.prepareStatement("INSERT INTO JHistory(UserID, conversion, conversionID)" + "VALUES(?, ?, ?)");
			try{
				ps = Con.prepareStatement("INSERT INTO HISTORY(UserID, conversion, conversionID)" + "VALUES(?, ?, ?)");
				ps.setString(1, ID);
				ps.setString(2, Conversion);
				ps.setString(3, conversionID);
				ps.executeUpdate();
				ps.close();}
			catch (NullPointerException e) {System.out.println("No history");}
		}
	}
	//Method to register user and write their credentials into the database
	public String RegisterUser() throws SQLException{
		String ID=java.util.UUID.randomUUID().toString();
		PreparedStatement ps = null;
		//Check if a potential User ID is already stored in the database, if so continue storing the data
		if(UserPresent(SearchUname)!= true){if(IDPresent(ID,1) != true){
			//ps = Con.prepareStatement("INSERT INTO (Name, token, ID)" + "VALUES(?, ?, ?)");
			ps = Con.prepareStatement("INSERT INTO USERS (username, password, ID)" + "VALUES(?, ?, ?)");

			ps.setString(1, this.SearchUname);
			ps.setString(2, this.SearchPassword);
			ps.setString(3, ID);
			ps.executeUpdate();}
		ps.close();
		//Con.close();
		return "Account successfully made";
		}
		else {return "Username taken";}
	}

	//Method to establish connection to the database
	/*
	private Connection getConnection() throws ClassNotFoundException, SQLException{
		//Class.forName("com.mysql.jdbc.Driver");
		//Credentials for the database
		Class.forName("com.mysql.cj.jdbc.Driver");
		String dbname = "group_a_dbs"; //<--Schema name
		String url = "jdbc:mysql://129.151.75.225:3306/" + dbname; //<--Insert IP
		String username = "202102_group_a"; 
		String Password = "Groupa-a7a8c"; //<--Put your groups password here
		System.out.println("Connected");
		return DriverManager.getConnection(url, username, Password);
	}
	 */

	private	  Connection getConnection() throws ClassNotFoundException, SQLException {
		//("com.mysql.jdbc.Drive")
		Class.forName("org.sqlite.JDBC");

		String DBName = "C:/Users/Kalabaz/Desktop/Assignment1DB.db";
		return DriverManager.getConnection("jdbc:sqlite:"+ DBName);
	}


	//Method to return a boolean value which is true if the data is present
	public boolean GetData () throws SQLException{
		Statement stmt = Con.createStatement();
		//RS = stmt.executeQuery("SELECT * FROM Jahanzeb");
		RS = stmt.executeQuery("SELECT * FROM USERS");


		//Cycle through the 'Jahanzeb' table
		while (RS.next()) {
			//String username = RS.getString("Name");
			String username = RS.getString("username");
			//String password = RS.getString("Token");
			String password = RS.getString("password");
			String ID = RS.getString("ID");
			System.err.println("------\n" + username + "," + password + "," + ID + "\n------\n");

			System.out.println("Stored uname " + SearchUname + " token =" + SearchPassword);
			System.out.println("Username1224= "+ username +" Token= "+password);

			if(username.equals(SearchUname) && password.equals(SearchPassword)){return true;}

		}
		stmt.close();
		RS.close();
		//Con.close();
		return false;
	}

	//Connect to the database
	public void ConnectToDB () throws ClassNotFoundException, SQLException {
		//The connection object code after @ is different every time
		// DO NOT REMOVE CONNECT TO DB OR THIS LINE. IT GETS LE CONNECTION
		Con = getConnection();
		//RS=GetData();
		System.out.println(Con);
		//Con.close();
	}
}
