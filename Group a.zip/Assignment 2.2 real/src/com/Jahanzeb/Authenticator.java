package com.Jahanzeb;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/***
 * @author Zear
 * This is a simple class to perform string comparison on a database.
 * This is not a proper authenticator and does not make use of encrypted tokens.
 */
@SuppressWarnings("serial")
public class Authenticator{
	private String uname = null;
	private String password = null;
	private String stored_username = null;
	private String stored_password = null;

	//Constructor
	Authenticator (String uname, String Password) throws IOException{
		this.uname= uname;
		this.password= Password;
	}

	// TODO: In assignment 2.2 discuss authentication tokens with the idea that
	// plain text comparison is not secure.
	public boolean authenticateUser() throws IOException, ClassNotFoundException, SQLException{	
		return checkCredentials() ? true : false;
		//return true;
	}

	/**
	 * This method only checks if a user exists within the MySQL Database.
	 * It is not efficient and uses plain text password.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */

	public boolean checkCredentials() throws ClassNotFoundException{
		//Declaring the variable to be returned
		boolean status = false;
		System.out.println("Connecting database...");

		try{
			//Creating an object to use methods in the DBUtility class
			DBUtility db = new DBUtility(uname, password);
			//Establish a connection to the database
			db.ConnectToDB();
			//Call the GetData method to see if the account is present
			status = db.GetData();
		} catch (SQLException e) {
			throw new IllegalStateException("Cannot connect the database!", e);
		}
		return status;
	}
	//Stores the error message for if the credentials are wrong.
	public String getAuthenticationMessage(){
		return "Username or password is incorrect";
	}
	//Returns the username of the user
	public String getUsername(){
		return this.stored_username;
	}
}
